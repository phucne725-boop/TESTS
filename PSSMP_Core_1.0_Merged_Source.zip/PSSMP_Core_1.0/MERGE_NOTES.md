# Merge notes
- Base: PSSMP Core Part 2.
- Added: Auth Java package and AUTH_FLOW.md from Part 3 Full.
- Replaced corrupted Part 3 PSSMPCore.java with a clean Part 2 bootstrap extended to instantiate and start AuthModule.
- Updated plugin.yml, config.yml and db/schema.sql for Auth.
- Original Part 2 and Part 3 archives were not modified.
