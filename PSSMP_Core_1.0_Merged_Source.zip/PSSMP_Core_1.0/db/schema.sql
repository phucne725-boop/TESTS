CREATE TABLE IF NOT EXISTS pssmp_player_profiles (
  uuid CHAR(36) NOT NULL PRIMARY KEY,
  last_known_name VARCHAR(16) NOT NULL,
  playtime_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
  first_joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_profile_name (last_known_name),
  INDEX idx_profile_last_seen (last_seen)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role and Discord-link tables are shared with API Part 1.
-- Do not create duplicate role/link tables in this module.

CREATE TABLE IF NOT EXISTS pssmp_auth_accounts (
  minecraft_uuid CHAR(36) NOT NULL PRIMARY KEY,
  password_hash VARCHAR(128) NOT NULL,
  password_salt VARCHAR(64) NOT NULL,
  pin_hash VARCHAR(128) NULL,
  pin_salt VARCHAR(64) NULL,
  pin_locked BOOLEAN NOT NULL DEFAULT FALSE,
  failed_password_attempts INT NOT NULL DEFAULT 0,
  password_kick_rounds INT NOT NULL DEFAULT 0,
  password_locked_until BIGINT NOT NULL DEFAULT 0,
  failed_pin_attempts INT NOT NULL DEFAULT 0,
  pin_kick_rounds INT NOT NULL DEFAULT 0,
  pin_locked_until BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
