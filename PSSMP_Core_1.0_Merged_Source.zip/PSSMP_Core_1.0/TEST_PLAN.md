# PSSMP Core Part 2 — test plan

Run these on a disposable test server/database before production:

1. Start Paper with the configured MySQL database and confirm Core enables.
2. Stop MySQL; confirm DB-backed `/stats` reports the configured unavailable message and does not claim success.
3. Restore MySQL; confirm the next Hikari connection attempt recovers without restarting Paper.
4. Join with a new Java UUID; verify exactly one `pssmp_player_profiles` row is created.
5. Rejoin with a changed display name; verify the same UUID row updates `last_known_name`.
6. Play for more than one save interval; verify playtime increases once per interval.
7. Quit; verify the final session segment is persisted.
8. Restart cleanly; verify the shutdown flush completes before the pool closes.
9. Add/remove each Discord role using API Part 1; verify Core sees the new snapshot within the configured polling interval.
10. Disconnect MySQL during role polling; verify last known permissions remain until a successful later poll.
11. Remove all roles from a linked Discord account; verify the online player's PSSMP role set becomes empty after the next successful poll.
12. Verify HELPER, SPECTATOR, SYSTEM, ADMIN and player-rank permission checks in each future module.

Record Paper build, Java version, MySQL version, test date and logs with every release candidate.
