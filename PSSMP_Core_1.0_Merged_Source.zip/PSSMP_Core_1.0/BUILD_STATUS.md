# Build status

- Source merge completed.
- Local Maven build was NOT run: this environment has OpenJDK 21 and Maven is not installed.
- The project currently declares Java release 25, so a valid build requires JDK 25 and Maven.
- A GitHub Actions workflow is included to build using Temurin 25.
- Do not treat this ZIP as a verified JAR or production-ready release until CI succeeds and the Auth flows are tested on a staging server.
