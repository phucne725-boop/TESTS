# PSSMP Core 1.0 — merged working source

This package combines the Core foundation from Part 2 with the Auth source package from Part 3 Full.

## Included
- MySQL connection pool (HikariCP)
- UUID player profiles and playtime tracking
- Custom permission/role snapshot services
- `/stats [player]`
- Auth commands: `/dangky`, `/dangnhap`, `/doimatkhau`, `/lock`, `/unlock`, `/dlock`
- Auth login barrier, password/PIN verification and account records

## Build
Requires JDK 25 and Maven. Run:

```bash
mvn clean package
```

The shaded plugin jar is produced under `target/PSSMP-Core-1.0.jar`.

## Database
Apply `db/schema.sql` to the configured MySQL database before first use. This creates the Core profile table and Auth account table. Role/link tables remain owned by the API package.

## Important verification status
This is a source merge, not a production certification. Paper API version in `pom.xml` is still provisional and must match the actual server. Test Auth flows on a staging server before production. Review `docs/AUTH_FLOW.md` and `REVIEW.md` for known design limitations.
