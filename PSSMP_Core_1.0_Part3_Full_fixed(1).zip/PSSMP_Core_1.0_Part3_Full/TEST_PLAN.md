# Auth Part 3 — test plan

1. New UUID joins: cannot move, interact, drop, pick up, break/place or open inventory before login.
2. New UUID uses `/dangky`; password mismatch is rejected; matching password creates one Auth row.
3. Existing UUID uses `/dangnhap`; correct password restores normal play.
4. Wrong password five times: kick; verify persisted attempt and kick-round counters.
5. Repeat five kick rounds: verify one-hour lockout blocks further login until expiry.
6. Join with PIN lock enabled: `/unlock` accepts correct PIN and rejects incorrect PIN.
7. `/lock`: enter PIN twice; account is marked PIN-locked and player is kicked.
8. `/dlock <password> <new PIN>`: correct password changes PIN; wrong password does not.
9. `/doimatkhau`: old password required; new password must be entered twice.
10. Wait 120 seconds without authentication: player is kicked.
11. Test two simultaneous sessions with same UUID; integrate with Core session policy and verify old session is kicked.
12. Test database outage during registration/login; no success message should be shown when persistence fails.
13. Test Bedrock and Java accounts separately; verify UUIDs remain separate.
14. Call trusted API password reset by UUID; verify only Auth row is deleted and profile/Discord/gameplay records remain.
15. Test after Paper restart; PIN lock, passwords and counters persist.
