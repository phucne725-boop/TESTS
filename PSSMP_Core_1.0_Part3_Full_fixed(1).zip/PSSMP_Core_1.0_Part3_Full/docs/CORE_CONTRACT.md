# Core integration contract

- Discord role membership is authoritative. API Part 1 writes complete snapshots to `pssmp_role_assignments`; Core polls that table and replaces in-memory role sets.
- If MySQL is unavailable during a role poll, Core retains the last known role state; it does not silently revoke staff permissions.
- Staff mapping: ADMIN all; HELPER account support; SPECTATOR anti-cheat inspection; SYSTEM allowed server/economy configuration. Donater/Booster/Media provide rank benefits.
- All player identities use Minecraft UUID. Names are display/search metadata only.
- Later modules must obtain `PSSMPServices` through Bukkit ServicesManager. They must not create separate MySQL pools or permission stores.
- Core's `PermissionManager` is the central policy entry point; later commands and GUI actions must check it server-side.
- No gameplay module is considered implemented merely because a service class exists.
