# Auth Part 3 — self-review status

## Implemented in source
- Six Auth commands registered.
- Password/PIN hashing with PBKDF2-HMAC-SHA256 and per-account random salt.
- MySQL Auth account schema keyed by Minecraft UUID.
- Registration/login/password change/PIN lock and PIN unlock flows.
- Login timeout and pre-auth gameplay restrictions.
- Separate persisted password/PIN failure counters.
- API-facing password reset repository operation that preserves non-Auth player data.

## Important limitations / blockers
- This source has not been compiled against the actual Paper server build.
- Exact Paper API artifact for the stated 26.3 server remains unconfirmed.
- Password and PIN one-hour lockout timestamps are checked before allowing the corresponding prompt. The fifth wrong attempt in each round increments a persisted kick-round counter; the fifth round sets a one-hour lockout. This SQL still requires a real MySQL test.
- The failed-attempt SQL update was revised to calculate lockout from pre-increment counters; confirm exact behavior with a real MySQL test.
- `AsyncPlayerChatEvent` is used for compatibility with the intended prompt flow; update to the server's current chat event API if deprecated/removed in the chosen build.
- The movement barrier restores default walk/fly speeds; production integration should preserve pre-auth player-specific speed values and coordinate with other plugins.
- `/dlock` arguments can appear in command logs. The requested syntax is implemented, but replace it with a secure chat-prompt variant before live deployment.
- Admin/Helper Discord `/unlock @player` and `/kptk @player` API routes are not wired in this part. The password-reset repository method is present for the later API integration.
- The source needs live tests for Bedrock/Floodgate UUID behavior, Java accounts, relogin, PIN lock, kick-round lockout and concurrent login attempts.

## No false completion claim
This is an implementation draft for Auth Part 3, not a certified production release. Run the build and the test plan on a disposable server before installing on the live server.
