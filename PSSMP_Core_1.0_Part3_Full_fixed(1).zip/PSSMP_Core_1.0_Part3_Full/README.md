# PSSMP Core 1.0 — Parts 2 + 3 (Full Source)

This ZIP contains the complete Core foundation from Part 2 plus the Auth module from Part 3, merged into one Maven project.

Included:
- MySQL connection pool, UUID profiles and playtime.
- `/stats [player]`.
- Custom PSSMP Permission Manager and Discord role snapshot sync.
- Auth: `/dangky`, `/dangnhap`, `/doimatkhau`, `/lock`, `/unlock`, `/dlock`.
- SQL schemas, integration contract, Auth flow, self-review and test plan.

## Build
Requires JDK 25 and Maven 3.9+. Confirm the exact Paper API artifact for the actual server build in `pom.xml`, then run `mvn clean package`.

## Database
Apply Part 1 API schema, then `db/schema.sql` from this package to the same MySQL database. The schema file includes the Core profile table and Auth table; do not create duplicate role/link tables.

## Important
This is source code, not a certified production binary. It has not been compiled or tested against the live server. Verify Paper version compatibility, MySQL behavior, and the tests in `TEST_PLAN.md` before deployment. `/kptk` and Discord-side `/unlock @player` still require trusted API/Bot wiring.
