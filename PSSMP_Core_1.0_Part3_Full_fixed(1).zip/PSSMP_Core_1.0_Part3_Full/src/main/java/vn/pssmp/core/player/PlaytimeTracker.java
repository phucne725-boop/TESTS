package vn.pssmp.core.player;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public final class PlaytimeTracker implements Listener {
    private final JavaPlugin plugin;
    private final ProfileRepository profiles;
    private final Map<UUID, Long> lastSavedAt = new ConcurrentHashMap<>();
    private int taskId = -1;

    public PlaytimeTracker(JavaPlugin plugin, ProfileRepository profiles) {
        this.plugin = plugin; this.profiles = profiles;
    }

    public void start() {
        long seconds = Math.max(15, plugin.getConfig().getLong("playtime.save-interval-seconds", 60));
        long ticks = seconds * 20L;
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, this::persistOnline, ticks, ticks);
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        profiles.upsertJoin(id, event.getPlayer().getName());
        lastSavedAt.put(id, System.currentTimeMillis());
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        Long started = lastSavedAt.remove(id);
        if (started != null) profiles.addPlaytime(id, Math.max(0, (System.currentTimeMillis() - started) / 1000));
        profiles.upsertJoin(id, event.getPlayer().getName());
    }

    private void persistOnline() {
        long now = System.currentTimeMillis();
        for (var player : Bukkit.getOnlinePlayers()) {
            Long previous = lastSavedAt.put(player.getUniqueId(), now);
            if (previous != null) profiles.addPlaytime(player.getUniqueId(),
                    Math.max(0, (now - previous) / 1000));
        }
    }

    public void flushAllSynchronously() {
        if (taskId >= 0) Bukkit.getScheduler().cancelTask(taskId);
        long now = System.currentTimeMillis();
        for (var entry : lastSavedAt.entrySet()) {
            long seconds = Math.max(0, (now - entry.getValue()) / 1000);
            if (seconds > 0) {
                try { profiles.addPlaytime(entry.getKey(), seconds).get(4, TimeUnit.SECONDS); }
                catch (Exception e) {
                    plugin.getLogger().severe("Could not flush playtime for " + entry.getKey() + "; inspect database before restart.");
                }
            }
        }
        lastSavedAt.clear();
    }
}
