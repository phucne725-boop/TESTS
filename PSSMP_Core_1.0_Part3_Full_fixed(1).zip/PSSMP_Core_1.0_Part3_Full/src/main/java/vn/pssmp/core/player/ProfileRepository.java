package vn.pssmp.core.player;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import vn.pssmp.core.db.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.logging.Level;

public final class ProfileRepository {
    private final JavaPlugin plugin;
    private final Database database;
    private final ExecutorService executor;

    public ProfileRepository(JavaPlugin plugin, Database database, ExecutorService executor) {
        this.plugin = plugin; this.database = database; this.executor = executor;
    }

    public void loadOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) upsertJoin(player.getUniqueId(), player.getName());
    }

    public void upsertJoin(UUID uuid, String name) {
        executor.execute(() -> {
            String sql = "INSERT INTO pssmp_player_profiles(uuid,last_known_name,playtime_seconds,first_joined,last_seen) " +
                    "VALUES(?,?,0,NOW(),NOW()) ON DUPLICATE KEY UPDATE last_known_name=VALUES(last_known_name),last_seen=NOW()";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuid.toString()); p.setString(2, name); p.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not persist player join profile for " + uuid, e);
            }
        });
    }

    public CompletableFuture<Boolean> addPlaytime(UUID uuid, long seconds) {
        return CompletableFuture.supplyAsync(() -> {
            if (seconds <= 0) return true;
            try (Connection c = database.connection();
                 PreparedStatement p = c.prepareStatement(
                         "UPDATE pssmp_player_profiles SET playtime_seconds=playtime_seconds+?,last_seen=NOW() WHERE uuid=?")) {
                p.setLong(1, seconds); p.setString(2, uuid.toString());
                return p.executeUpdate() == 1;
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not persist playtime for " + uuid, e);
                return false;
            }
        }, executor);
    }

    public CompletableFuture<Optional<PlayerProfile>> findByNameOrUuid(String input) {
        return CompletableFuture.supplyAsync(() -> {
            boolean uuidInput;
            try { UUID.fromString(input); uuidInput = true; } catch (Exception e) { uuidInput = false; }
            String sql = uuidInput
                    ? "SELECT uuid,last_known_name,playtime_seconds,first_joined,last_seen FROM pssmp_player_profiles WHERE uuid=?"
                    : "SELECT uuid,last_known_name,playtime_seconds,first_joined,last_seen FROM pssmp_player_profiles WHERE LOWER(last_known_name)=LOWER(?) ORDER BY last_seen DESC LIMIT 1";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuidInput ? UUID.fromString(input).toString() : input);
                try (ResultSet r = p.executeQuery()) {
                    if (!r.next()) return Optional.empty();
                    return Optional.of(new PlayerProfile(UUID.fromString(r.getString("uuid")),
                            r.getString("last_known_name"), r.getLong("playtime_seconds"),
                            r.getTimestamp("first_joined").toInstant(), r.getTimestamp("last_seen").toInstant()));
                }
            } catch (SQLException e) {
                throw new IllegalStateException("Database stats lookup failed", e);
            }
        }, executor);
    }
}
