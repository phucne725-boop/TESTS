package vn.pssmp.core.auth;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class AuthCommand implements CommandExecutor {
    private final AuthController auth;
    public AuthCommand(AuthController auth) { this.auth = auth; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Lệnh này chỉ dành cho người chơi.");
            return true;
        }
        switch (label.toLowerCase()) {
            case "dangky" -> auth.beginRegister(player);
            case "dangnhap" -> auth.beginLogin(player);
            case "doimatkhau" -> {
                if (!auth.isAuthenticated(player.getUniqueId())) player.sendMessage(ChatColor.RED + "Bạn cần đăng nhập trước.");
                else auth.beginPasswordChange(player);
            }
            case "lock" -> {
                if (!auth.isAuthenticated(player.getUniqueId())) player.sendMessage(ChatColor.RED + "Bạn cần đăng nhập trước.");
                else auth.beginLock(player);
            }
            case "unlock" -> auth.beginUnlock(player);
            case "dlock" -> {
                if (!auth.isAuthenticated(player.getUniqueId())) player.sendMessage(ChatColor.RED + "Bạn cần đăng nhập trước.");
                else if (args.length != 2) player.sendMessage(ChatColor.RED + "Cách dùng: /dlock <password> <new PIN>");
                else auth.changePinWithPassword(player, args[0], args[1]);
            }
            default -> player.sendMessage(ChatColor.RED + "Lệnh Auth không hợp lệ.");
        }
        return true;
    }
}
