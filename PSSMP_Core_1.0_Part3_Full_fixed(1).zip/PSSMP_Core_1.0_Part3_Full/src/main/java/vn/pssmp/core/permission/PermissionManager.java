package vn.pssmp.core.permission;

import org.bukkit.entity.Player;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PermissionManager {
    private final Map<UUID, EnumSet<PssmpRole>> roles = new ConcurrentHashMap<>();

    public void replaceRoles(UUID uuid, Set<PssmpRole> snapshot) {
        roles.put(uuid, snapshot.isEmpty() ? EnumSet.noneOf(PssmpRole.class) : EnumSet.copyOf(snapshot));
    }
    public Set<PssmpRole> getRoles(UUID uuid) {
        EnumSet<PssmpRole> found = roles.get(uuid);
        return found == null ? Set.of() : Set.copyOf(found);
    }
    public boolean hasRole(UUID uuid, PssmpRole role) {
        EnumSet<PssmpRole> found = roles.get(uuid);
        return found != null && found.contains(role);
    }
    public boolean hasPermission(Player player, String node) {
        if (player == null || node == null) return false;
        UUID id = player.getUniqueId();
        if (hasRole(id, PssmpRole.ADMIN)) return true;
        return switch (node) {
            case "pssmp.staff.account" -> hasRole(id, PssmpRole.HELPER);
            case "pssmp.staff.anticheat" -> hasRole(id, PssmpRole.SPECTATOR);
            case "pssmp.staff.system" -> hasRole(id, PssmpRole.SYSTEM);
            case "pssmp.rank.donater" -> hasRole(id, PssmpRole.DONATER);
            case "pssmp.rank.booster" -> hasRole(id, PssmpRole.BOOSTER);
            case "pssmp.rank.media" -> hasRole(id, PssmpRole.MEDIA);
            default -> false;
        };
    }
    public boolean canUseStaffCommand(Player player, PssmpRole role) {
        return hasRole(player.getUniqueId(), PssmpRole.ADMIN) || hasRole(player.getUniqueId(), role);
    }
}
