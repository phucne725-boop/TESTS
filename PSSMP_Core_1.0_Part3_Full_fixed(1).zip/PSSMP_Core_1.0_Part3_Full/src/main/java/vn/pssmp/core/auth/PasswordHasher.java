package vn.pssmp.core.auth;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordHasher {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int ITERATIONS = 210_000;
    private static final int KEY_BITS = 256;

    public record Hash(String encoded, String salt) {}

    public Hash hash(char[] secret) {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return new Hash(derive(secret, salt), Base64.getEncoder().encodeToString(salt));
    }

    public boolean verify(char[] secret, String encoded, String saltText) {
        if (encoded == null || saltText == null) return false;
        try {
            byte[] salt = Base64.getDecoder().decode(saltText);
            byte[] expected = Base64.getDecoder().decode(encoded);
            byte[] actual = Base64.getDecoder().decode(deriveBytes(secret, salt));
            return MessageDigest.isEqual(expected, actual);
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private String derive(char[] secret, byte[] salt) {
        return Base64.getEncoder().encodeToString(deriveBytes(secret, salt));
    }

    private byte[] deriveBytes(char[] secret, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(secret, salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("Secure password hashing is unavailable", e);
        } finally {
            spec.clearPassword();
        }
    }
}
