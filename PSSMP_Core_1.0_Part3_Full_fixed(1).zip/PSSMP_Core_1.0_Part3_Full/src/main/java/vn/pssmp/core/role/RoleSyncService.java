package vn.pssmp.core.role;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import vn.pssmp.core.db.Database;
import vn.pssmp.core.permission.PermissionManager;
import vn.pssmp.core.permission.PssmpRole;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.logging.Level;

public final class RoleSyncService {
    private final JavaPlugin plugin;
    private final Database database;
    private final PermissionManager permissions;
    private final ExecutorService executor;
    private final Map<String, PssmpRole> roleIds = new HashMap<>();
    private int taskId = -1;

    public RoleSyncService(JavaPlugin plugin, Database database, PermissionManager permissions, ExecutorService executor) {
        this.plugin = plugin; this.database = database; this.permissions = permissions; this.executor = executor;
        for (PssmpRole role : PssmpRole.values()) {
            String id = plugin.getConfig().getString("roles.discord-role-ids." + role.name(), "");
            if (!id.isBlank()) roleIds.put(id, role);
        }
    }

    public void start() {
        long interval = Math.max(5, plugin.getConfig().getLong("roles.sync-interval-seconds", 30));
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, this::syncAsync, 20L, interval * 20L);
    }

    private void syncAsync() {
        executor.execute(() -> {
            Map<UUID, EnumSet<PssmpRole>> snapshot = new HashMap<>();
            try (Connection c = database.connection();
                 PreparedStatement p = c.prepareStatement("SELECT minecraft_uuid,discord_role_id FROM pssmp_role_assignments");
                 ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    PssmpRole role = roleIds.get(r.getString("discord_role_id"));
                    if (role != null) snapshot.computeIfAbsent(UUID.fromString(r.getString("minecraft_uuid")),
                            ignored -> EnumSet.noneOf(PssmpRole.class)).add(role);
                }
                Bukkit.getScheduler().runTask(plugin, () -> {
                    for (var entry : snapshot.entrySet()) permissions.replaceRoles(entry.getKey(), entry.getValue());
                    // Clear online accounts whose complete authoritative role snapshot is empty.
                    for (var player : Bukkit.getOnlinePlayers()) {
                        if (!snapshot.containsKey(player.getUniqueId())) permissions.replaceRoles(player.getUniqueId(), Set.of());
                    }
                });
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Role sync failed; retaining last known role state.", e);
            }
        });
    }

    public void stop() { if (taskId >= 0) Bukkit.getScheduler().cancelTask(taskId); }
}
