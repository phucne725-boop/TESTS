# PSSMP API Part 1 — Test plan

## Build checks
- [ ] Java 25 toolchain available.
- [ ] `mvn -B clean verify` completes successfully.
- [ ] `target/pssmp-api-1.0.0.jar` exists.

## Environment and database
- [ ] Missing required environment variables stop startup with a clear error.
- [ ] API refuses an HMAC secret shorter than 32 characters.
- [ ] MySQL connection pool starts and schema is applied before the service is exposed.
- [ ] Invalid DB credentials fail startup rather than running in a degraded write mode.

## HTTP and authentication
- [ ] `GET /health` reports service/database health without exposing secrets.
- [ ] Every `/v1/*` endpoint rejects missing/invalid timestamp, nonce, or signature.
- [ ] HMAC-SHA256 signs exactly `timestamp + LF + nonce + LF + raw UTF-8 body`.
- [ ] Expired timestamps are rejected.
- [ ] Reused nonce values are rejected, including concurrent replay attempts.
- [ ] Request bodies larger than 64 KiB are rejected.
- [ ] Invalid JSON and unsupported methods return safe 4xx responses.

## Account linking
- [ ] Link creation accepts a valid Minecraft UUID and returns a one-time code.
- [ ] Code is stored as SHA-256 hash, has a TTL, and is never logged in plaintext.
- [ ] Expired, consumed, or unknown codes cannot be used.
- [ ] Discord snowflakes are handled as strings.
- [ ] Unique constraints prevent one Discord ID or Minecraft UUID from being linked twice.
- [ ] Link verification is transactional and safe under simultaneous attempts.

## Roles and account actions
- [ ] Role sync replaces the complete role snapshot transactionally.
- [ ] Duplicate role IDs are ignored.
- [ ] PIN unlock and password reset create pending actions; they do not directly modify password hashes.
- [ ] Unlink removes only the Discord link, not Minecraft player data.

## Production readiness (must be tested on target host)
- [ ] API is behind TLS/reverse proxy or private network access.
- [ ] Firewall allows only intended Bot/Core callers.
- [ ] Process restarts automatically and logs rotate safely.
- [ ] MySQL backups and restore have been tested.
- [ ] Bot and Minecraft Core pass live integration tests using the same HMAC contract.
