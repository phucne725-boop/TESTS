# Deployment notes

1. Provision MySQL 8+ and create a dedicated database/user with least-privilege access.
2. Apply `db/schema.sql` to the PSSMP database.
3. Copy `.env.example` values into the process environment; never upload real secrets into Git.
4. Generate a random HMAC secret of at least 32 characters. Use the exact same secret in trusted Bot/Core clients.
5. Build with Java 25 and Maven 3.9+: `mvn clean package`.
6. Run: `java --add-modules jdk.httpserver -jar target/pssmp-api-1.0.0.jar`.
7. Keep the API private where possible. If remote access is required, use TLS and firewall allow-lists.
8. Confirm `/health`, then run the integration checks in `TEST_PLAN.md`.

The API is a standalone Java service, not a Bukkit/Paper plugin. It can run separately from the Minecraft server and Discord Bot.
