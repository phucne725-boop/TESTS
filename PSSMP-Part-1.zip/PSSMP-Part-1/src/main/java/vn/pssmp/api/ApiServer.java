package vn.pssmp.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;

public final class ApiServer {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static HikariDataSource dataSource;
    private static String hmacSecret;
    private static long maxSkewSeconds;
    private static long linkTtlSeconds;

    private ApiServer() {}

    public static void main(String[] args) throws Exception {
        String jdbc = required("PSSMP_DB_URL");
        String dbUser = required("PSSMP_DB_USER");
        String dbPassword = required("PSSMP_DB_PASSWORD");
        hmacSecret = required("PSSMP_HMAC_SECRET");
        if (hmacSecret.length() < 32) throw new IllegalStateException("HMAC secret must be at least 32 characters");
        maxSkewSeconds = Long.parseLong(env("PSSMP_HMAC_MAX_SKEW_SECONDS", "60"));
        linkTtlSeconds = Long.parseLong(env("PSSMP_LINK_CODE_TTL_SECONDS", "600"));

        HikariConfig hc = new HikariConfig();
        hc.setJdbcUrl(jdbc);
        hc.setUsername(dbUser);
        hc.setPassword(dbPassword);
        hc.setMaximumPoolSize(10);
        hc.setMinimumIdle(2);
        hc.setConnectionTimeout(5000);
        hc.setPoolName("PSSMP-API-MySQL");
        dataSource = new HikariDataSource(hc);

        try (Connection c = dataSource.getConnection()) {
            if (!c.isValid(3)) throw new SQLException("MySQL validation failed");
        }

        String host = env("PSSMP_API_HOST", "127.0.0.1");
        int port = Integer.parseInt(env("PSSMP_API_PORT", "8787"));
        int workers = Integer.parseInt(env("PSSMP_API_WORKERS", "8"));
        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 64);
        server.setExecutor(Executors.newFixedThreadPool(Math.max(2, workers)));
        server.createContext("/health", ApiServer::health);
        server.createContext("/v1/link/create", ApiServer::linkCreate);
        server.createContext("/v1/link/verify", ApiServer::linkVerify);
        server.createContext("/v1/discord/roles/sync", ApiServer::roleSync);
        server.createContext("/v1/account/unlock-pin", ApiServer::unlockPin);
        server.createContext("/v1/account/reset-password", ApiServer::resetPassword);
        server.createContext("/v1/account/unlink", ApiServer::unlink);
        server.createContext("/v1/rank/assign", ApiServer::rankAssign);
        server.createContext("/v1/rank/revoke", ApiServer::rankRevoke);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            server.stop(2);
            dataSource.close();
        }));
        server.start();
        System.out.printf("PSSMP API listening on %s:%d%n", host, port);
    }

    private static void health(HttpExchange x) throws IOException {
        if (!"GET".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        ObjectNode out = JSON.createObjectNode();
        out.put("status", "ok");
        out.put("service", "PSSMP-API-1.0");
        try (Connection c = dataSource.getConnection()) {
            out.put("database", c.isValid(2) ? "ok" : "degraded");
            send(x, c.isValid(2) ? 200 : 503, out);
        } catch (SQLException e) {
            out.put("database", "unavailable");
            send(x, 503, out);
        }
    }

    private static void linkCreate(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String uuid = text(body, "minecraftUuid");
        if (!validUuid(uuid)) { error(x, 400, "invalid_minecraft_uuid"); return; }
        String code = String.format("%06d", new java.security.SecureRandom().nextInt(1_000_000));
        long expires = Instant.now().getEpochSecond() + linkTtlSeconds;
        try (Connection c = dataSource.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "INSERT INTO pssmp_link_codes(code_hash,minecraft_uuid,expires_at,created_at) VALUES(?,?,FROM_UNIXTIME(?),NOW())")) {
            p.setString(1, sha256(code));
            p.setString(2, UUID.fromString(uuid).toString());
            p.setLong(3, expires);
            p.executeUpdate();
            ObjectNode out = JSON.createObjectNode();
            out.put("code", code);
            out.put("expiresAt", expires);
            send(x, 200, out);
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void linkVerify(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String code = text(body, "code");
        String discordId = text(body, "discordUserId");
        if (code == null || !code.matches("\\d{6}") || discordId == null || !discordId.matches("\\d{17,20}")) {
            error(x, 400, "invalid_link_input"); return;
        }
        try (Connection c = dataSource.getConnection()) {
            c.setAutoCommit(false);
            try {
                String uuid;
                try (PreparedStatement p = c.prepareStatement(
                    "SELECT minecraft_uuid FROM pssmp_link_codes WHERE code_hash=? AND expires_at>NOW() AND consumed_at IS NULL FOR UPDATE")) {
                    p.setString(1, sha256(code));
                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) { c.rollback(); error(x, 404, "link_code_invalid_or_expired"); return; }
                        uuid = r.getString(1);
                    }
                }
                try (PreparedStatement p = c.prepareStatement(
                    "SELECT discord_user_id,minecraft_uuid FROM pssmp_discord_links " +
                    "WHERE discord_user_id=? OR minecraft_uuid=? FOR UPDATE")) {
                    p.setString(1, discordId); p.setString(2, uuid);
                    try (ResultSet r = p.executeQuery()) {
                        while (r.next()) {
                            boolean samePair = discordId.equals(r.getString("discord_user_id"))
                                    && uuid.equals(r.getString("minecraft_uuid"));
                            if (!samePair) {
                                c.rollback(); error(x, 409, "discord_or_minecraft_account_already_linked"); return;
                            }
                        }
                    }
                }
                try (PreparedStatement p = c.prepareStatement(
                    "INSERT INTO pssmp_discord_links(discord_user_id,minecraft_uuid,linked_at) VALUES(?,?,NOW()) " +
                    "ON DUPLICATE KEY UPDATE linked_at=NOW()")) {
                    p.setString(1, discordId); p.setString(2, uuid); p.executeUpdate();
                }
                try (PreparedStatement p = c.prepareStatement("UPDATE pssmp_link_codes SET consumed_at=NOW() WHERE code_hash=?")) {
                    p.setString(1, sha256(code)); p.executeUpdate();
                }
                c.commit();
                ObjectNode out = JSON.createObjectNode();
                out.put("linked", true); out.put("minecraftUuid", uuid); out.put("discordUserId", discordId);
                send(x, 200, out);
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void roleSync(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String discordId = text(body, "discordUserId");
        JsonNode roles = body.get("roleIds");
        if (discordId == null || !discordId.matches("\\d{17,20}") || roles == null || !roles.isArray()) {
            error(x, 400, "invalid_role_snapshot"); return;
        }
        try (Connection c = dataSource.getConnection()) {
            c.setAutoCommit(false);
            try {
                String uuid = null;
                try (PreparedStatement p = c.prepareStatement("SELECT minecraft_uuid FROM pssmp_discord_links WHERE discord_user_id=? FOR UPDATE")) {
                    p.setString(1, discordId);
                    try (ResultSet r = p.executeQuery()) { if (r.next()) uuid = r.getString(1); }
                }
                if (uuid == null) { c.rollback(); error(x, 404, "discord_account_not_linked"); return; }
                try (PreparedStatement p = c.prepareStatement("DELETE FROM pssmp_role_assignments WHERE minecraft_uuid=?")) {
                    p.setString(1, uuid); p.executeUpdate();
                }
                Set<String> uniqueRoles = new LinkedHashSet<>();
                for (JsonNode role : roles) {
                    if (role.isTextual() && role.asText().matches("\\d{17,20}")) uniqueRoles.add(role.asText());
                }
                try (PreparedStatement p = c.prepareStatement(
                    "INSERT INTO pssmp_role_assignments(minecraft_uuid,discord_user_id,discord_role_id,synced_at) VALUES(?,?,?,NOW())")) {
                    for (String roleId : uniqueRoles) {
                        p.setString(1, uuid); p.setString(2, discordId); p.setString(3, roleId); p.addBatch();
                    }
                    if (!uniqueRoles.isEmpty()) p.executeBatch();
                }
                c.commit();
                ObjectNode out = JSON.createObjectNode();
                out.put("synced", true); out.put("minecraftUuid", uuid); out.put("roleCount", uniqueRoles.size());
                send(x, 200, out);
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void unlockPin(HttpExchange x) throws IOException {
        accountAction(x, "UNLOCK_PIN");
    }

    private static void resetPassword(HttpExchange x) throws IOException {
        accountAction(x, "RESET_PASSWORD");
    }

    private static void accountAction(HttpExchange x, String action) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String target = text(body, "minecraftUuid");
        String actor = text(body, "actorDiscordId");
        String reason = text(body, "reason");
        if (!validUuid(target) || actor == null || !actor.matches("\\d{17,20}")) {
            error(x, 400, "invalid_account_action"); return;
        }
        try (Connection c = dataSource.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "INSERT INTO pssmp_account_actions(minecraft_uuid,action,actor_discord_id,reason,status,created_at) VALUES(?,?,?,?, 'PENDING',NOW())")) {
            p.setString(1, UUID.fromString(target).toString());
            p.setString(2, action); p.setString(3, actor); p.setString(4, reason == null ? "" : reason);
            p.executeUpdate();
            ObjectNode out = JSON.createObjectNode();
            out.put("accepted", true); out.put("action", action); out.put("status", "PENDING");
            send(x, 202, out);
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void unlink(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String target = text(body, "minecraftUuid");
        if (!validUuid(target)) { error(x, 400, "invalid_minecraft_uuid"); return; }
        try (Connection c = dataSource.getConnection();
             PreparedStatement p = c.prepareStatement("DELETE FROM pssmp_discord_links WHERE minecraft_uuid=?")) {
            p.setString(1, UUID.fromString(target).toString());
            int changed = p.executeUpdate();
            ObjectNode out = JSON.createObjectNode();
            out.put("unlinked", changed > 0);
            send(x, 200, out);
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void rankAssign(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String uuid = text(body, "minecraftUuid");
        String rank = text(body, "rank");
        String sourceId = text(body, "sourceId");
        String actor = text(body, "actorDiscordId");
        JsonNode expiryNode = body.get("expiresAt");
        if (!validUuid(uuid) || rank == null || !Set.of("DONATER", "BOOSTER", "MEDIA").contains(rank)
                || sourceId == null || sourceId.length() > 128
                || (actor != null && !actor.matches("\\d{17,20}"))
                || (expiryNode != null && !expiryNode.isNull() && !expiryNode.canConvertToLong())) {
            error(x, 400, "invalid_rank_assignment"); return;
        }
        try (Connection c = dataSource.getConnection();
             PreparedStatement p = c.prepareStatement(
                 "INSERT INTO pssmp_rank_assignments(minecraft_uuid,rank_code,source_id,actor_discord_id,expires_at,created_at,updated_at) " +
                 "VALUES(?,?,?,?,IF(? IS NULL,NULL,FROM_UNIXTIME(?)),NOW(),NOW()) " +
                 "ON DUPLICATE KEY UPDATE source_id=VALUES(source_id),actor_discord_id=VALUES(actor_discord_id),expires_at=VALUES(expires_at),updated_at=NOW()")) {
            Long expiry = expiryNode == null || expiryNode.isNull() ? null : expiryNode.asLong();
            p.setString(1, UUID.fromString(uuid).toString());
            p.setString(2, rank);
            p.setString(3, sourceId);
            p.setString(4, actor);
            if (expiry == null) { p.setNull(5, java.sql.Types.BIGINT); p.setNull(6, java.sql.Types.BIGINT); }
            else { p.setLong(5, expiry); p.setLong(6, expiry); }
            p.executeUpdate();
            ObjectNode out = JSON.createObjectNode();
            out.put("assigned", true); out.put("minecraftUuid", UUID.fromString(uuid).toString());
            out.put("rank", rank); out.put("sourceId", sourceId);
            if (expiry == null) out.putNull("expiresAt"); else out.put("expiresAt", expiry);
            send(x, 200, out);
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static void rankRevoke(HttpExchange x) throws IOException {
        if (!auth(x)) return;
        if (!"POST".equals(x.getRequestMethod())) { methodNotAllowed(x); return; }
        JsonNode body = readJson(x);
        if (body == null) return;
        String uuid = text(body, "minecraftUuid");
        String rank = text(body, "rank");
        String sourceId = text(body, "sourceId");
        if (!validUuid(uuid) || rank == null || !Set.of("DONATER", "BOOSTER", "MEDIA").contains(rank)) {
            error(x, 400, "invalid_rank_revocation"); return;
        }
        String sql = sourceId == null
                ? "DELETE FROM pssmp_rank_assignments WHERE minecraft_uuid=? AND rank_code=?"
                : "DELETE FROM pssmp_rank_assignments WHERE minecraft_uuid=? AND rank_code=? AND source_id=?";
        try (Connection c = dataSource.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, UUID.fromString(uuid).toString()); p.setString(2, rank);
            if (sourceId != null) p.setString(3, sourceId);
            int changed = p.executeUpdate();
            ObjectNode out = JSON.createObjectNode(); out.put("revoked", changed > 0); out.put("rank", rank);
            send(x, 200, out);
        } catch (SQLException e) { error(x, 500, "database_error"); }
    }

    private static boolean auth(HttpExchange x) throws IOException {
        String ts = x.getRequestHeaders().getFirst("X-PSSMP-Timestamp");
        String nonce = x.getRequestHeaders().getFirst("X-PSSMP-Nonce");
        String sig = x.getRequestHeaders().getFirst("X-PSSMP-Signature");
        if (ts == null || nonce == null || sig == null || !nonce.matches("[A-Za-z0-9_-]{16,128}") || !sig.matches("[a-fA-F0-9]{64}")) {
            error(x, 401, "missing_or_invalid_auth_headers"); return false;
        }
        long timestamp;
        try { timestamp = Long.parseLong(ts); } catch (NumberFormatException e) { error(x, 401, "invalid_timestamp"); return false; }
        long now = Instant.now().getEpochSecond();
        if (Math.abs(now - timestamp) > maxSkewSeconds) { error(x, 401, "stale_request"); return false; }
        byte[] raw = x.getRequestBody().readNBytes(65_537);
        if (raw.length > 65_536) { error(x, 413, "request_body_too_large"); return false; }
        String message = ts + "\n" + nonce + "\n" + new String(raw, StandardCharsets.UTF_8);
        String expected = hmac(message);
        if (!MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII), sig.toLowerCase().getBytes(StandardCharsets.US_ASCII))) {
            error(x, 401, "bad_signature"); return false;
        }
        try (Connection c = dataSource.getConnection();
             PreparedStatement p = c.prepareStatement("INSERT INTO pssmp_api_nonces(nonce,created_at) VALUES(?,NOW())")) {
            p.setString(1, nonce); p.executeUpdate();
            x.setAttribute("pssmp.rawBody", raw);
            return true;
        } catch (SQLException e) {
            error(x, 401, "replayed_nonce_or_database_error"); return false;
        }
    }

    private static JsonNode readJson(HttpExchange x) throws IOException {
        byte[] raw = (byte[]) x.getAttribute("pssmp.rawBody");
        if (raw == null) raw = x.getRequestBody().readAllBytes();
        try { return JSON.readTree(raw); }
        catch (Exception e) { error(x, 400, "invalid_json"); return null; }
    }

    private static String hmac(String message) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(hmacSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(message.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    private static String sha256(String value) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8))); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }

    private static String text(JsonNode n, String field) {
        JsonNode v = n.get(field);
        return v != null && v.isTextual() && !v.asText().isBlank() ? v.asText().trim() : null;
    }
    private static boolean validUuid(String s) {
        try { UUID.fromString(s); return true; } catch (Exception e) { return false; }
    }
    private static String required(String key) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) throw new IllegalStateException("Missing environment variable: " + key);
        return v;
    }
    private static String env(String key, String fallback) {
        String v = System.getenv(key); return v == null || v.isBlank() ? fallback : v;
    }
    private static void methodNotAllowed(HttpExchange x) throws IOException { error(x, 405, "method_not_allowed"); }
    private static void error(HttpExchange x, int code, String message) throws IOException {
        ObjectNode out = JSON.createObjectNode(); out.put("error", message); send(x, code, out);
    }
    private static void send(HttpExchange x, int code, JsonNode body) throws IOException {
        byte[] bytes = JSON.writeValueAsBytes(body);
        x.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        x.getResponseHeaders().set("Cache-Control", "no-store");
        x.sendResponseHeaders(code, bytes.length);
        try (var os = x.getResponseBody()) { os.write(bytes); }
    }
}
