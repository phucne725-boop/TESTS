package vn.phutsmile.pscore.player;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import vn.phutsmile.pscore.PSCore;

public final class PlayerDataListener implements Listener {

    private final PSCore plugin;

    public PlayerDataListener(PSCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        try {
            plugin.getPlayerDataService().handleJoin(
                event.getPlayer().getUniqueId(),
                event.getPlayer().getName()
            );
        } catch (RuntimeException exception) {
            plugin.getLogger().severe(
                "Could not record join data for " + event.getPlayer().getName()
            );
            exception.printStackTrace();
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        try {
            plugin.getPlayerDataService().handleQuit(
                event.getPlayer().getUniqueId(),
                event.getPlayer().getName()
            );
        } catch (RuntimeException exception) {
            plugin.getLogger().severe(
                "Could not save playtime for " + event.getPlayer().getName()
            );
            exception.printStackTrace();
        }
    }
}
