package vn.phutsmile.pscore.player;

import vn.phutsmile.pscore.PSCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Stores player profile information and measures playtime sessions.
 * All database operations are synchronized because the plugin uses one
 * SQLite connection shared by its services.
 */
public final class PlayerDataService {

    private final PSCore plugin;
    private final ConcurrentMap<UUID, Long> sessionStartedAt = new ConcurrentHashMap<>();

    public PlayerDataService(PSCore plugin) {
        this.plugin = plugin;
    }

    public void handleJoin(UUID uuid, String playerName) {
        long now = System.currentTimeMillis() / 1000L;

        synchronized (plugin.getDatabaseManager()) {
            try {
                Connection connection = plugin.getDatabaseManager().getConnection();

                try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO player_data
                        (uuid, player_name, playtime_seconds, first_join, last_seen)
                    VALUES (?, ?, 0, ?, ?)
                    ON CONFLICT(uuid) DO UPDATE SET
                        player_name = excluded.player_name,
                        last_seen = excluded.last_seen
                    """)) {
                    statement.setString(1, uuid.toString());
                    statement.setString(2, playerName);
                    statement.setLong(3, now);
                    statement.setLong(4, now);
                    statement.executeUpdate();
                }
            } catch (SQLException exception) {
                throw new IllegalStateException("Cannot save player join data.", exception);
            }
        }

        sessionStartedAt.put(uuid, System.currentTimeMillis());
    }

    public void handleQuit(UUID uuid, String playerName) {
        saveSession(uuid, playerName);
    }

    public void saveSession(UUID uuid, String playerName) {
        Long startedAt = sessionStartedAt.remove(uuid);
        if (startedAt == null) {
            return;
        }

        long elapsedSeconds = Math.max(
            0L,
            (System.currentTimeMillis() - startedAt) / 1000L
        );
        long now = System.currentTimeMillis() / 1000L;

        synchronized (plugin.getDatabaseManager()) {
            try (PreparedStatement statement =
                     plugin.getDatabaseManager().getConnection().prepareStatement("""
                         UPDATE player_data
                         SET player_name = ?,
                             playtime_seconds = playtime_seconds + ?,
                             last_seen = ?
                         WHERE uuid = ?
                         """)) {
                statement.setString(1, playerName);
                statement.setLong(2, elapsedSeconds);
                statement.setLong(3, now);
                statement.setString(4, uuid.toString());
                statement.executeUpdate();
            } catch (SQLException exception) {
                // Restore the session marker so a later shutdown/quit can retry.
                sessionStartedAt.putIfAbsent(uuid, startedAt);
                throw new IllegalStateException("Cannot save player playtime.", exception);
            }
        }
    }

    public long getCurrentPlaytimeSeconds(UUID uuid, long savedSeconds) {
        Long startedAt = sessionStartedAt.get(uuid);
        if (startedAt == null) {
            return savedSeconds;
        }

        long currentSessionSeconds = Math.max(
            0L,
            (System.currentTimeMillis() - startedAt) / 1000L
        );
        return savedSeconds + currentSessionSeconds;
    }

    public Optional<PlayerProfile> findByUuid(UUID uuid) {
        synchronized (plugin.getDatabaseManager()) {
            try (PreparedStatement statement =
                     plugin.getDatabaseManager().getConnection().prepareStatement("""
                         SELECT uuid, player_name, playtime_seconds, first_join, last_seen
                         FROM player_data
                         WHERE uuid = ?
                         """)) {
                statement.setString(1, uuid.toString());

                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) {
                        return Optional.empty();
                    }
                    return Optional.of(readProfile(result));
                }
            } catch (SQLException exception) {
                throw new IllegalStateException("Cannot read player profile.", exception);
            }
        }
    }

    public Optional<PlayerProfile> findByName(String playerName) {
        synchronized (plugin.getDatabaseManager()) {
            try (PreparedStatement statement =
                     plugin.getDatabaseManager().getConnection().prepareStatement("""
                         SELECT uuid, player_name, playtime_seconds, first_join, last_seen
                         FROM player_data
                         WHERE player_name = ? COLLATE NOCASE
                         ORDER BY last_seen DESC
                         LIMIT 1
                         """)) {
                statement.setString(1, playerName);

                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) {
                        return Optional.empty();
                    }
                    return Optional.of(readProfile(result));
                }
            } catch (SQLException exception) {
                throw new IllegalStateException("Cannot search player profile.", exception);
            }
        }
    }

    private PlayerProfile readProfile(ResultSet result) throws SQLException {
        return new PlayerProfile(
            UUID.fromString(result.getString("uuid")),
            result.getString("player_name"),
            result.getLong("playtime_seconds"),
            result.getLong("first_join"),
            result.getLong("last_seen")
        );
    }

    public record PlayerProfile(
        UUID uuid,
        String playerName,
        long playtimeSeconds,
        long firstJoin,
        long lastSeen
    ) {
    }
}
