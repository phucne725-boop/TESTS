package vn.phutsmile.pscore;

import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import vn.phutsmile.pscore.commands.BalanceCommand;
import vn.phutsmile.pscore.commands.PayCommand;
import vn.phutsmile.pscore.commands.StatsCommand;
import vn.phutsmile.pscore.database.DatabaseManager;
import vn.phutsmile.pscore.economy.EconomyHook;
import vn.phutsmile.pscore.player.PlayerDataListener;
import vn.phutsmile.pscore.player.PlayerDataService;

public final class PSCore extends JavaPlugin {

    private static PSCore instance;

    private DatabaseManager databaseManager;
    private EconomyHook economyHook;
    private PlayerDataService playerDataService;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        getLogger().info("Starting PSCore...");

        try {
            databaseManager = new DatabaseManager(this);
            databaseManager.connect();
            databaseManager.initializeTables();
        } catch (Exception exception) {
            getLogger().severe("Cannot initialize database!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        economyHook = new EconomyHook(this);
        if (!economyHook.setup()) {
            getLogger().warning(
                "Vault Economy provider not found. Economy commands will be unavailable."
            );
        }

        playerDataService = new PlayerDataService(this);
        getServer().getPluginManager().registerEvents(
            new PlayerDataListener(this),
            this
        );

        // Players already online when this plugin enables are also registered.
        for (Player player : getServer().getOnlinePlayers()) {
            try {
                playerDataService.handleJoin(
                    player.getUniqueId(),
                    player.getName()
                );
            } catch (RuntimeException exception) {
                getLogger().severe(
                    "Could not initialize player data for " + player.getName()
                );
                exception.printStackTrace();
            }
        }

        registerCommands();

        getLogger().info("--------------------------------");
        getLogger().info("PSCore enabled!");
        getLogger().info("Server: PhutSmileSmp");
        getLogger().info("--------------------------------");
    }

    private void registerCommands() {
        registerCommand("bal", new BalanceCommand(this));
        registerCommand("pay", new PayCommand(this));
        registerCommand("stats", new StatsCommand(this));
    }

    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = getCommand(name);

        if (command == null) {
            getLogger().severe("Command " + name + " is missing from plugin.yml!");
            return;
        }

        command.setExecutor(executor);
    }

    @Override
    public void onDisable() {
        if (playerDataService != null) {
            for (Player player : getServer().getOnlinePlayers()) {
                try {
                    playerDataService.saveSession(
                        player.getUniqueId(),
                        player.getName()
                    );
                } catch (RuntimeException exception) {
                    getLogger().severe(
                        "Could not save final playtime for " + player.getName()
                    );
                    exception.printStackTrace();
                }
            }
        }

        if (databaseManager != null) {
            databaseManager.close();
        }

        getLogger().info("PSCore disabled.");
        instance = null;
    }

    public static PSCore getInstance() {
        return instance;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public EconomyHook getEconomyHook() {
        return economyHook;
    }

    public PlayerDataService getPlayerDataService() {
        return playerDataService;
    }
}
