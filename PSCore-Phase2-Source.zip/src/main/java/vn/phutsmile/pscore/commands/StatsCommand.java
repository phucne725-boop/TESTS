package vn.phutsmile.pscore.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import vn.phutsmile.pscore.PSCore;
import vn.phutsmile.pscore.player.PlayerDataService.PlayerProfile;
import vn.phutsmile.pscore.utils.MoneyFormatter;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.UUID;

public final class StatsCommand implements CommandExecutor {

    private static final DateTimeFormatter DATE_FORMAT =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
            .withZone(ZoneId.systemDefault());

    private final PSCore plugin;

    public StatsCommand(PSCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(
        CommandSender sender,
        Command command,
        String label,
        String[] args
    ) {
        if (args.length > 1) {
            sender.sendMessage("§cSử dụng: /stats [player]");
            return true;
        }

        PlayerProfile profile;

        try {
            if (args.length == 0) {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("§cConsole cần chỉ định người chơi: /stats <player>");
                    return true;
                }

                Optional<PlayerProfile> result =
                    plugin.getPlayerDataService().findByUuid(player.getUniqueId());

                if (result.isEmpty()) {
                    sender.sendMessage("§cChưa tìm thấy dữ liệu của bạn. Hãy thử vào lại server.");
                    return true;
                }

                profile = result.get();
            } else {
                if (sender instanceof Player viewer
                    && !viewer.getName().equalsIgnoreCase(args[0])
                    && !viewer.hasPermission("pscore.stats.others")) {
                    sender.sendMessage("§cBạn không có quyền xem chỉ số người khác.");
                    return true;
                }

                Optional<PlayerProfile> result =
                    plugin.getPlayerDataService().findByName(args[0]);

                if (result.isEmpty()) {
                    sender.sendMessage("§cKhông tìm thấy hồ sơ người chơi này.");
                    return true;
                }

                profile = result.get();
            }

            sendProfile(sender, profile);
        } catch (RuntimeException exception) {
            plugin.getLogger().severe("Could not load player statistics.");
            exception.printStackTrace();
            sender.sendMessage("§cKhông thể tải chỉ số lúc này. Hãy báo staff.");
        }

        return true;
    }

    private void sendProfile(CommandSender sender, PlayerProfile profile) {
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(profile.uuid());

        sender.sendMessage("§8§m--------------------------------");
        sender.sendMessage("§b§lTHỐNG KÊ NGƯỜI CHƠI");
        sender.sendMessage("§7Tên: §f" + profile.playerName());
        long playtime = plugin.getPlayerDataService().getCurrentPlaytimeSeconds(
            profile.uuid(),
            profile.playtimeSeconds()
        );
        sender.sendMessage("§7Thời gian chơi: §e" + formatDuration(playtime));

        if (profile.firstJoin() > 0) {
            sender.sendMessage("§7Lần đầu tham gia: §f" + DATE_FORMAT.format(
                Instant.ofEpochSecond(profile.firstJoin())
            ));
        } else {
            sender.sendMessage("§7Lần đầu tham gia: §8Chưa có dữ liệu");
        }

        if (profile.lastSeen() > 0) {
            sender.sendMessage("§7Lần online gần nhất: §f" + DATE_FORMAT.format(
                Instant.ofEpochSecond(profile.lastSeen())
            ));
        } else {
            sender.sendMessage("§7Lần online gần nhất: §8Chưa có dữ liệu");
        }

        if (plugin.getEconomyHook() != null
            && plugin.getEconomyHook().isAvailable()) {
            double balance = plugin.getEconomyHook().getEconomy().getBalance(offlinePlayer);
            sender.sendMessage("§7Số dư: §a" + MoneyFormatter.formatWithSymbol(balance));
        }

        sender.sendMessage("§8§m--------------------------------");
    }

    private String formatDuration(long totalSeconds) {
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;

        if (days > 0) {
            return days + " ngày " + hours + " giờ " + minutes + " phút";
        }
        if (hours > 0) {
            return hours + " giờ " + minutes + " phút";
        }
        return minutes + " phút";
    }
}
